﻿from ui.streamlit_app import run

if __name__ == "__main__":
    run()
