"""
ui/sqlite_browser.py

Small Streamlit-based SQLite browser so developers can inspect the project's SQLite DB
from the running Streamlit UI. Supports listing tables, previewing rows, and running simple
SELECT queries. This is intentionally lightweight and only supports SQLite file URLs.
"""
from typing import Optional
import io
import sqlite3
import pandas as pd
import streamlit as st

from services.db import get_database_url


def _get_sqlite_path(db_url: str) -> Optional[str]:
    """Return an absolute file path for sqlite file URLs.

    Attempts these locations for relative paths:
    - as given (absolute or relative to current working directory)
    - relative to repository root (parent of the `ui` package)

    Returns None for non-file URLs or in-memory DBs.
    """
    if not db_url:
        return None
    if not db_url.startswith("sqlite:///"):
        return None
    path = db_url.replace("sqlite:///", "")
    if path == ":memory:":
        return None

    # If absolute path, return if exists
    import os

    if os.path.isabs(path) and os.path.exists(path):
        return os.path.abspath(path)

    # Try relative to current working directory
    cwd_path = os.path.abspath(os.path.join(os.getcwd(), path))
    if os.path.exists(cwd_path):
        return cwd_path

    # Try relative to repo root (parent of this file's parent)
    this_file_dir = os.path.dirname(__file__)
    repo_root = os.path.abspath(os.path.join(this_file_dir, ".."))
    repo_path = os.path.abspath(os.path.join(repo_root, path))
    if os.path.exists(repo_path):
        return repo_path

    # Not found
    return None


def show_db_browser():
    st.title("🗄️ SQLite Browser")

    # Determine DB URL from service helper (respects DATABASE_URL env var)
    db_url = get_database_url()
    st.sidebar.subheader("Database")
    st.sidebar.write(db_url)

    sqlite_path = _get_sqlite_path(db_url)
    if not sqlite_path:
        st.error("This DB browser only supports a file-based SQLite database (e.g. sqlite:///kb_articles.db).")
        st.info("If you want to inspect an in-memory DB, run your code with a temporary file DB or use sqlite-utils locally.")
        return

    st.write(f"Browsing SQLite file: `{sqlite_path}`")

    try:
        conn = sqlite3.connect(sqlite_path)
    except sqlite3.Error as exc:
        st.error(f"Failed to open SQLite DB: {exc}")
        return

    with conn:
        cur = conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;")
        tables = [r[0] for r in cur.fetchall()]

    if not tables:
        st.info("No tables found in the database.")
        return

    table = st.selectbox("Select table", tables)

    limit = st.number_input("Rows to preview", min_value=1, max_value=1000, value=20)
    if st.button("Refresh preview"):
        st.experimental_rerun()

    # Preview rows
    try:
        df = pd.read_sql_query(f"SELECT * FROM \"{table}\" LIMIT {limit}", conn)
        st.subheader(f"Preview — {table}")
        st.dataframe(df)

        # CSV download
        csv_buf = io.StringIO()
        df.to_csv(csv_buf, index=False)
        st.download_button("Download preview as CSV", data=csv_buf.getvalue(), file_name=f"{table}_preview.csv", mime="text/csv")
    except Exception as e:
        st.error(f"Failed to preview table: {e}")

    st.markdown("---")
    st.subheader("Run a custom SELECT query")
    st.info("Only SELECT queries are allowed. Be careful with long-running queries.")
    default_query = f"SELECT * FROM \"{table}\" LIMIT 100"
    query = st.text_area("SQL (SELECT only)", value=default_query, height=140)

    if st.button("Run query"):
        q = query.strip()
        if not q.lower().startswith("select"):
            st.error("Only SELECT queries are allowed for safety.")
        else:
            try:
                qdf = pd.read_sql_query(q, conn)
                st.write(f"Query returned {len(qdf)} rows")
                st.dataframe(qdf)
                csv_buf2 = io.StringIO()
                qdf.to_csv(csv_buf2, index=False)
                st.download_button("Download query results as CSV", data=csv_buf2.getvalue(), file_name="query_results.csv", mime="text/csv")
            except Exception as ex:
                st.error(f"Query failed: {ex}")

    conn.close()
